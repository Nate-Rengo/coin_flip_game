public class Main {
    public static void main(String[] args){
        new Main().go();
    }
    void go(){
        Controller controller= new Controller();
    }
}


